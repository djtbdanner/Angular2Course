"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var jdf_calculator_module_1 = require('./jdf-calculator.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(jdf_calculator_module_1.JDFCalculatorModule);
//# sourceMappingURL=main.js.map